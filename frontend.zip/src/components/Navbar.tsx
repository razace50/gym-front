import React from "react";
import logo from "../../public/images/logo.png";
import { Button } from "./ui/button";
import { AlignJustify } from "lucide-react";

const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const menuRef = React.useRef<HTMLDivElement>(null);
  const buttonRef = React.useRef<HTMLButtonElement>(null);

  const navItems = [
    { id: 1, name: "Home", link: "/" },
    { id: 2, name: "About Us", link: "/about" },
    { id: 3, name: "Classes", link: "/classes" },
    { id: 4, name: "Trainers", link: "/trainers" },
    { id: 5, name: "Services", link: "/services" },
    { id: 6, name: "Membership", link: "/membership" },
    { id: 7, name: "Contact", link: "/contact" },
    { id: 8, name: "Login", link: "/login" },
  ];

  //close menu when a nav item is clicked
  const handleNavItemClick = () => {
    // Close the menu when a nav item is clicked
    setIsMenuOpen(false);
  };
  // Close the menu when clicking outside
  React.useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        menuRef.current &&
        !menuRef.current.contains(event.target as Node) &&
        buttonRef.current &&
        !buttonRef.current.contains(event.target as Node)
      ) {
        setIsMenuOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isMenuOpen]);

  return (
    <>
      <nav className="bg-slate-950 text-white px-6 py-2 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <img src={logo} className="h-[75px] w-[75px]" alt="logo" />
          <a href="/" className="flex flex-col ml-2 hover:text-slate-300">
            <div className="flex flex-col space-y-0">
              <h1 className="text-3xl font-semibold">Hamro</h1>
              <span className="text-3xl font-semibold"> Gym</span>
            </div>
          </a>
        </div>

        {/* Hamburger Icon for small devices */}
        <div className="lg:hidden sm:block order-2">
          <Button
            ref={buttonRef}
            variant={"secondary"}
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="p-2"
          >
            <AlignJustify />
          </Button>
        </div>

        {/* Navigation Items for Large Devices */}
        <div className="hidden lg:flex items-center justify-between space-x-12">
          {navItems.map((item, index) => (
            <a
              key={index}
              href={item.link}
              className="text-lg font-semibold hover:underline"
            >
              {item.name}
            </a>
          ))}
        </div>

        {/* Show menu Items on Small Devices when Hamburger is Clicked */}
        <div
          ref={menuRef}
          className={`absolute  top-[80px] left-0 w-full z-50 bg-slate-950 lg:hidden ${
            isMenuOpen ? "block" : "hidden"
          } hover:shadow-lg p-4`}
        >
          {navItems.map((item, index) => (
            <a
              key={index}
              href={item.link}
              className="text-center block py-2 text-lg font-semibold hover:underline"
              onClick={handleNavItemClick}
            >
              {item.name}
            </a>
          ))}
        </div>

        {/* Join Membership Button */}
        <div className="order-1">
          <a href="/membership">
            <Button variant={"secondary"}>Join Membership</Button>
          </a>
        </div>
      </nav>
    </>
  );
};

export default Navbar;
