const About = () => {
  return (
    <>
      <div className="flex flex-col items-center justify-center h-screen bg-slate-800 text-white">
        <h1 className="text-4xl font-bold">About Us</h1>
        <p className="mt-4 text-lg">
          Welcome to Hamro Gym! We are dedicated to helping you achieve your
          fitness goals. Our state-of-the-art facility offers a wide range of
          equipment and classes to suit all levels.
        </p>
        <p className="mt-2 text-lg">
          Join us today and start your journey towards a healthier, happier you!
        </p>
      </div>
    </>
  );
};

export default About;
