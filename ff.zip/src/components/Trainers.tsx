import React from 'react'

const Trainers = () => {
  return (
    <>
    <div></div>
    <div></div>
    </>
  )
}

export default Trainers
